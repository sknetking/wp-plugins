const ws = new WebSocket('ws://localhost:8080/'); // Adjust URL if necessary

ws.onopen = function(event) {
	console.log('Connected to WebSocket server');
	get_massage(1);
};

ws.onmessage = function(event) {
	const message = event.data;
	appendMessage('<li class="clearfix"> <div class="message-data align-right"> <span class="message-data-time" >10:10 AM, Today</span> &nbsp; &nbsp; <span class="message-data-name" >Olia</span> <i class="fa fa-circle me"></i> </div> <div class="message other-message float-right">'+message+'</div> </li>');
};

ws.onerror = function(error) {
	console.error('WebSocket error: ', error);
	appendMessage('WebSocket error: ' + error.message);
};

function sendMessage() {
	const messageInput = document.getElementById('message');
	const message = messageInput.value.trim();
             
	if (message && jQuery("input[name='users']:checked").val()) {
		ws.send(message);
		appendMessage('<li class="clearfix"> <div class="message-data align-right"> <span class="message-data-time" >'+currentTime()+'</span> &nbsp; &nbsp; <span class="message-data-name" >Olia</span> <i class="fa fa-circle me"></i> </div> <div class="message other-message float-right"> '+message+'</div> </li>');
		messageInput.value = '';
		store_massage(message);
	}else {
		alert('Select any one person for chat.');
	}
	
}

function appendMessage(message) {
	document.getElementById('chat-history').innerHTML += (message);

	// Auto-scroll to bottom
	document.getElementById('chatbox').scrollTop = document.getElementById('chatbox').scrollHeight;
}

function store_massage(massage){
	jQuery.ajax({
		type: 'POST',
		url:ajax_object.ajax_url, // WordPress AJAX URL
		data: {
			action: 'insert_message',
			user_id:1, //$('#user_id').val(), // Assuming #user_id is your input field for user_id
			message:massage,// Assuming #message is your input field for message
			receiver_id: jQuery("input[name='users']:checked").val(),// Assuming #receiver_id is your input field for receiver_id
		},
		success: function(response) {
			console.log(response);
			// Handle success here (e.g., show success message)
		},
		error: function(xhr, status, error) {
			console.error(xhr.responseText);
			// Handle error here (e.g., show error message)
		}
	});

}

function get_massage(user_id){
	jQuery.ajax({
		type: 'POST',
		url:ajax_object.ajax_url, // WordPress AJAX URL
		data: {
			action: 'get_message',
			user_id:user_id, //$('#user_id').val(), // Assuming #user_id is your input field for user_id
		},
		success: function(response) {
			console.log(response);
			var obj = JSON.parse(response);
			// Handle success here (e.g., show success message)
			for(let val of obj){
				if(ajax_object.current_user == val.message_to ){
					let temp ='<li class="clearfix"> <div class="message-data align-right"> <span class="message-data-time" >'+val.timestamp+'</span> &nbsp; &nbsp; <span class="message-data-name" >Olia</span> <i class="fa fa-circle me"></i> </div> <div class="message other-message float-right"> '+val.message_to+':'+val.message+'</div> </li>';
				appendMessage(temp);
					
				}else{
					let temp = '<li> <div class="message-data"> <span class="message-data-name"><i class="fa fa-circle online"></i> Vincent</span> <span class="message-data-time">10:12 AM, Today</span> </div> <div class="message my-message">'+val.message_to+':'+val.message+'</div> </li>';
				appendMessage(temp);
				}
				
			}
			
		},
		error: function(xhr, status, error) {
			console.error(xhr.responseText);
			// Handle error here (e.g., show error message)
		}
	});
}

jQuery(".ulist").change(function()
{
jQuery(".ulist").prop('checked',false);
jQuery(this).prop('checked',true);
});

function currentTime(){
	// Create a new Date object for the current date and time
let currentDate = new Date();

// Get hours and minutes from the date object
let hours = currentDate.getHours();
let minutes = currentDate.getMinutes();

// Determine whether it's AM or PM
let period = hours >= 12 ? 'PM' : 'AM';

// Convert hours from 24-hour to 12-hour format
hours = hours % 12;
hours = hours ? hours : 12; // the hour '0' should be '12' in 12-hour clock

// Format minutes to have leading zero if less than 10
minutes = minutes < 10 ? '0' + minutes : minutes;

// Construct the time string in the desired format
let currentTime = hours + ':' + minutes + ' ' + period + ', Today';

// Display the result
return(currentTime);
}