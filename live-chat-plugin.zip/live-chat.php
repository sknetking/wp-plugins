<?php
/*
 * Plugin Name:       Live Chat Plugin
 * Plugin URI:        https://livechat.com/plugins/livechat
 * Description:       Handle the basics with this plugin.
 * Version:           1.10.3
 * Requires PHP:      7.2
 * Author:           Shyam
 * Author URI:        https://author.example.com/
 * License:           GPL v2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Update URI:        https://example.com/my-plugin/
 */

function wpdocs_plugin_admin_init() {
    // Register our script.
    wp_enqueue_style( 'mystyle', plugins_url( '/style.css', __FILE__ ) );
	 wp_enqueue_script('custom-script', plugins_url('/custom-script.js',__FILE__), array('jquery'), null, true);
	 wp_localize_script('custom-script', 'ajax_object',
        array('ajax_url' => admin_url('admin-ajax.php'),'current_user'=> wp_get_current_user()->ID)
    );
	
}
add_action('init', 'wpdocs_plugin_admin_init' );



register_activation_hook( __FILE__, 'activate_custom_plugin' );

function activate_custom_plugin() {
 global $wpdb;
 $table_name = $wpdb->prefix . 'custom_messages';

$charset_collate = $wpdb->get_charset_collate();

$sql = "CREATE TABLE $table_name (
   id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
     message TEXT,
    time DATETIME,
    receiver_id INT,
    UNIQUE KEY unique_message (user_id, time, receiver_id),
   INDEX idx_receiver_id (receiver_id)
) $charset_collate;";

require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
dbDelta( $sql );
}
//user get online or offline 
// Function to add user ID to the list of logged-in users
function add_logged_in_user($user_id) {
	$logged_users = get_option('logged_users', array()); // Retrieve current logged-in users array
	$logged_users[] = $user_id; // Add user ID to the array
	update_option('logged_users', $logged_users); // Update option with new array
}

// Function to remove user ID from the list of logged-in users
function remove_logged_in_user($user_id) {
	$logged_users = get_option('logged_users', array()); // Retrieve current logged-in users array

	// Check if user ID exists in the array and remove it
	if (($key = array_search($user_id, $logged_users)) !== false) {
		unset($logged_users[$key]);
	}

	update_option('logged_users', $logged_users); // Update option with modified array
}
// Hook into user login event
add_action('wp_login', 'track_user_login', 10, 2);
function track_user_login($user_login, $user) {
	add_logged_in_user($user->ID); // Add user to logged-in users list
}

// Hook into user logout event (optional)
add_action('wp_logout', 'track_user_logout');
function track_user_logout() {
	$current_user = wp_get_current_user();
	if ($current_user && $current_user->ID) {
		remove_logged_in_user($current_user->ID); // Remove user from logged-in users list
	}
}
//$logged_in_users = get_option('logged_users', array());
//print_r($logged_in_users);
//online offline checking 

function get_all_user() {
    $users = get_users(array(
        'fields'  => array('ID', 'user_login'), // Fetch user IDs and usernames
    ));

    if (!empty($users)) {
        foreach ($users as $user) {
            $user_id = $user->ID;
            $username = $user->user_login;

             $logged_in_users = get_option('logged_users', array());
			$user_status = in_array($user_id, $logged_in_users) ? 'online' : 'offline';
            ?>
            <li class="clearfix">
                <input type="checkbox" value="<?php echo $user_id; ?>" id="<?php echo 'user'.$user_id; ?>" name="users" class='ulist'>
                <label class='user-select' for="<?php echo 'user'.$user_id; ?>">
                    <img src="https://s3-us-west-2.amazonaws.com/s.cdpn.io/195612/chat_avatar_10.jpg" alt="avatar" />
                    <div class="about">
                        <div class="name"><?php echo $username; ?></div>
                        <div class="status">
                            <span class="<?php echo $user_status; ?>"> <?php echo ucfirst($user_status); ?></span>
                        </div>
                    </div>
                </label>
            </li>
            <?php 
        }
    } else {
        echo 'No users found.';
    }
}

 function live_chat(){
  ob_start();
	 if(is_user_logged_in()):
?>

 <div class="container clearfix">
    <div class="people-list" id="people-list">
      <div class="search">
        <input type="text" placeholder="search" />
        <i class="fa fa-search"></i>
      </div>
      <ul class="list">
         <?php echo get_all_user();?>     
      </ul>
    </div>
    
    <div class="chat" id="chatbox">
      <div class="chat-header clearfix">
        <img src="https://s3-us-west-2.amazonaws.com/s.cdpn.io/195612/chat_avatar_01_green.jpg" alt="avatar" />
        
        <div class="chat-about">
          <div class="chat-with">Chat with Vincent Porter</div>
          <div class="chat-num-messages">already 1 902 messages</div>
        </div>
        <i class="fa fa-star"></i>
      </div> <!-- end chat-header -->
      
      <div class="chat-history" >
        <ul id='chat-history'>
     
		  </ul>
        
      </div> <!-- end chat-history -->
      
      <div class="chat-message clearfix">
        <textarea name="message-to-send" id="message"  placeholder ="Type your message" rows="3"></textarea>
                
         <button onclick="sendMessage()">Send</button>

      </div> <!-- end chat-message -->
      
    </div> <!-- end chat -->
    
  </div> <!-- end container -->

<?php
  else:
	 echo "<a href='/wp-admin'>Login for live chat</a>";
    endif;
return(ob_get_clean());

 }
 add_shortcode('live_chat', 'live_chat');


// Register AJAX handler for inserting messages
add_action('wp_ajax_insert_message', 'insert_message');
add_action('wp_ajax_nopriv_insert_message', 'insert_message'); // Allow for non-logged in users

function insert_message() {
    global $wpdb;
 $table_name = $wpdb->prefix . 'custom_messages';

    // Retrieve data sent via AJAX
    $user_id = isset($_POST['user_id']) ? intval($_POST['user_id']) : null;
    $message = isset($_POST['message']) ? sanitize_text_field($_POST['message']) : '';
    $time = current_time('mysql');
    $receiver_id = isset($_POST['receiver_id']) ? intval($_POST['receiver_id']) : null;

    // Prepare data for insertion
    $data = array(
        'user_id' => get_current_user_id(),
        'message' => $message,
        'time' => $time,
        'receiver_id' => $receiver_id,
    );

    // Insert data into the database
    $wpdb->insert($table_name, $data);

    // Check if insertion was successful
    if ($wpdb->insert_id) {
        echo 'Message inserted successfully.';
    } else {
        echo 'Failed to insert message.';
    }	
    // Always exit to avoid further execution
    wp_die();
}

add_action('wp_ajax_get_message', 'get_message_cback');
add_action('wp_ajax_nopriv_get_message', 'get_message_cback'); // Allow for non-logged in users

function get_message_cback() {
  // Sanitize the message_id to prevent SQL injection
  global $wpdb;
$table_name = $wpdb->prefix .'custom_messages';
$query = "SELECT * FROM $table_name";
$results = $wpdb->get_results($query);

if ($results) {
	$data =[];
    foreach ($results as $result) {
        // Access each row's fields       
		$data_temp = ['user_id'=>$result->user_id,'message'=>$result->message,'message_to'=>$result->receiver_id,'timestamp'=>$result->time];	
      	array_push($data,$data_temp);
	}
		echo json_encode($data);

} else {
    echo "No results found.";
}
die();
}